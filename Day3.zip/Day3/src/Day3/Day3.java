package Day3;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Day3 {
    public static void main(String[] args) {
        /*
        Person joao = new Person("Joao", "Toronto", "789878979", 25, 'M');
        System.out.println(joao.toString());
        
        Person shashank = new Person();
        shashank.setName();
        System.out.println("Name: " + shashank.getName());
        shashank.setAddress();
        System.out.println("Address: " + shashank.getAddress());
        shashank.setPhone();
        System.out.println("Phone: " + shashank.getPhone());
        shashank.setAge();
        System.out.println("Age: " + shashank.getAge());
        shashank.setGender();
        System.out.println("Gender: " + shashank.getGender());
        
        System.out.println("-----------------------------\n" + shashank.toString());
        */
        Person saloni = new Person();
        saloni.setData();
        System.out.println(saloni.toString());
    }  
    
}
