/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class HelloWorld {
    public static void main(String args[]){
        System.out.println("Hello World");
        //System.err.println("");
        //System.in
        
        int number = 10;
        float fnumber = 10.2f;
        double dnumber = 10.23455;
        short n1;
        long n2;
        
        number *= 10;
        System.out.println("mumber: " + number);
        
        number = 20;
        System.out.println("number: " + (number + 10));
        System.out.println(10 + number + "number: ");
        
        //number = number / 0;
        
        char ch = 'a';
        System.out.println("ch: " + ch);
        System.out.println("ch: " + (char)(ch + 1));
        
        ch++;
        System.out.println("ch: " + ch);
        
        ch++;
        System.out.println("ch: " + ch);
        
        ++ch;
        System.out.println("ch: " + ch);
        
        ch = 'a';
        char anotherCh = ++ch;
        System.out.println("ch: " + ch);
        System.out.println("anotherCh: " + anotherCh);
        
        String name = "Joao";
        System.out.println("Name: " + name);
        
        boolean flag = false;
        System.out.println("flag: " + flag);
        
        if (!flag) {
            System.out.println("Name: " + name);
        } else {
            System.out.println("Name is missing");
        }
        
        char vowel = 'a';
        
        switch(vowel){
            case 'a':
            case 'e':
            case 'i':
            case 'o':
            case 'u':
                System.out.println("given character is vowel");
                break;
            default:
                System.out.println("given character is NOT vowel");
        }
        
        switch(10+20){
            case 10:
                System.out.println("not match");
            break;
            case 30:
                System.out.println("matched");
            break;
            default:
                System.out.println("can't determine");
                break;
        }
        
        String province = "ON";
        switch(province){
            case "ON":
                System.out.println("Ontario");
            break;
            case "AB":
                System.out.println("Alberta");
                break;
            default:
                System.out.println("");
                break;
        }
        
    }
}
