/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package day8;

import java.util.Comparator;

/**
 *
 * @author macstudent
 */
public class Books {
    int bookId;
    String bookTitle;
    int bookRating;

    public Books() {
        this.bookId = 0;
        this.bookTitle = "Unknown";
        this.bookRating = 0;
    }

    public Books(int bookId, String bookTitle, int bookRating) {
        this.bookId = bookId;
        this.bookTitle = bookTitle;
        this.bookRating = bookRating;
    }

    public int getBookId() {
        return bookId;
    }

    public void setBookId(int bookId) {
        this.bookId = bookId;
    }

    public String getBookTitle() {
        return bookTitle;
    }

    public void setBookTitle(String bookTitle) {
        this.bookTitle = bookTitle;
    }

    public int getBookRating() {
        return bookRating;
    }

    public void setBookRating(int bookRating) {
        this.bookRating = bookRating;
    }
    
    void displayInfo(){
        System.out.println("BookID: " + this.bookId +
                "\nBook Title: " + this.bookTitle +
                "\nBook Rating: " + this.bookRating);
    }
}

class bookRatingComparator implements Comparator<Books>{
    @Override
    public int compare(Books o1, Books o2) {
        return o1.bookRating == o2.bookRating ? 0 : o1.bookRating < o2.bookRating ? 1 : -1; 
    }
}

class bookTitleComparator implements Comparator<Books>{
    @Override
    public int compare(Books o1, Books o2) {
        return o1.bookTitle.compareToIgnoreCase(o2.bookTitle);
    }
}
    