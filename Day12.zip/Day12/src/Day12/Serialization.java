/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day12;

import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;

/**
 *
 * @author macstudent
 * @version 1.0
 * @since 13 Jun 2018
 * 
 */
public class Serialization {
    /**
     * 
     * @param args main args
     * @return No return value
     * @exception IOException while performing Input Output from file
     * @exception ClassNotFoundException while reading object
     * @see IOException
     * @see ClassNotFoundException
     */
    public static void main(String[] args) {
        Employee emp = new Employee();
        emp.name = "Ashley";
        emp.address = "Vancouver";
        emp.SSN = 44444444;
        emp.number = 101;
        
        //Serialization
        try {
            FileOutputStream fileOut = new FileOutputStream("employee.txt");
            ObjectOutputStream out = new ObjectOutputStream(fileOut);
            
            out.writeObject(emp);
            out.close();
            fileOut.close();
            
            System.out.println("Serialized data is saved as employee.txt");
        } catch (IOException i) {
            i.printStackTrace();
        }
        
        //Deserialization
        
        Employee e = null;
        try {
            FileInputStream fileIn = new FileInputStream("employee.txt");
            ObjectInputStream in = new ObjectInputStream(fileIn);
            
            e = (Employee) in.readObject();
            
            in.close();
            fileIn.close();
            
        } catch (IOException i) {
            i.printStackTrace();
            return;
        }catch (ClassNotFoundException c){
            System.out.println("\nEmployee class not found");
            c.printStackTrace();
            return;
        }
    }
}
