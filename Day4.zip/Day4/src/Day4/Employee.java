/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day4;

import java.util.Scanner;

/**
 *
 * @author macstudent
 */

//inheritance
public class Employee extends Person{
    String empID;
    int dept;
    String joiningDate;

    public Employee() {
        super();
        this.empID = "temp";
        this.dept = 0;
        this.joiningDate = "not started yet";
    }
    
    public Employee(String name, String address, String phone, int age, char gender, String empID, int dept, String joiningDate) {
        super(name, address, phone, age, gender);
        this.empID = empID;
        this.dept = dept;
        this.joiningDate = joiningDate;
    }
    
    @Override
    public String toString() {
        String personalDetails = super.toString();
        String data = "Employee Id: " + this.empID + "\nDepartment: " + this.dept + "\nJoining Date: " + this.joiningDate + "\n";
        data = personalDetails + data; 
        return data; 
    }

    public String getEmpID() {
        return empID;
    }

    public void setEmpID(String empID) {
        this.empID = empID;
    }

    public int getDept() {
        return dept;
    }

    public void setDept(int dept) {
        this.dept = dept;
    }

    public String getJoiningDate() {
        return joiningDate;
    }

    public void setJoiningDate(String joiningDate) {
        this.joiningDate = joiningDate;
    }
    
    
    
    
}
