/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day4;

import java.util.Scanner;


/**
 *
 * @author macstudent
 */
public class Person {
    private String name;
    private String address;
    private String phone;
    private int age;
    private char gender;
    Scanner in = new Scanner(System.in);

    
    //
    public Person() {
        this.name = "Unknown";
        this.address = "Unknown";
        this.phone = "Unknown";
        this.age = 1;
        this.gender = 'U';
    }
    
    
    //parameterized constructor
    public Person(String name, String address, String phone, int age, char gender) {
        this.name = name;
        this.address = address;
        this.phone = phone;
        this.age = age;
        this.gender = gender;
    }

    // Copy constructor
    Person(Person anotherPerson) {
        this.name = anotherPerson.name;
        this.address = anotherPerson.address;
        this.phone = anotherPerson.phone;
        this.age = anotherPerson.age;
        this.gender = anotherPerson.gender;
    }

    public String getName() {
        return name;
    }
    
    public void setName() {
        System.out.println("Enter name: ");
        name = in.nextLine();
    }

    public String getAddress() {
        return address;
    }

    public void setAddress() {
        System.out.println("Enter address: ");
        address = in.nextLine();
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone() {
        System.out.println("Enter phone: ");
        phone = in.nextLine();
    }

    public int getAge() {
        return age;
    }

    public void setAge() {
        System.out.println("Enter age: ");
        age = Integer.parseInt(in.nextLine());
    }

    public char getGender() {
        return gender;
    }

    public void setGender() {
        System.out.println("Enter gender: ");
        gender = (char)Integer.parseInt(in.nextLine());
    }

    @Override
    public String toString() {
        return "Name: " + name + "\nAddress: " + address + "\nPhone: " + phone + "\nAge: " + age + "\nGender: " + gender + "\n";
    }
    
    void setData(){
        setName();
        setAddress();
        setPhone();
        setAge();
        setGender();
    }
}
