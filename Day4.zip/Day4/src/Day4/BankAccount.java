/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Day4;

/**
 *
 * @author macstudent
 */
public class BankAccount extends Bank {
    private String acNumber;
    private float balance;

    public BankAccount(int id, String name, String acNumber, float balance) {
        super(id, name);
        this.acNumber = acNumber;
        this.balance = balance;
    }

    public String getAcNumber() {
        return acNumber;
    }

    public void setAcNumber(String acNumber) {
        this.acNumber = acNumber;
    }

    public float getBalance() {
        return balance;
    }

    public void setBalance(float balance) {
        this.balance = balance;
    }

    @Override
    public String toString() {
        String bankDetails = super.toString();
        String data = "Ac Number: " + this.acNumber + "\nBalance: " + this.balance + "\n";
        data = bankDetails + data; 
        return data; 
    }
    
    
    
    
}
