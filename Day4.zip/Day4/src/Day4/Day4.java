package Day4;

/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

/**
 *
 * @author macstudent
 */
public class Day4 {
    public static void main(String[] args) {
        /*
        Person j = new Person();
        System.out.println(j.toString());
        
        Person alay = new Person("Alay", "USA", "123456", 25, 'M');
        System.out.println(alay.toString());
        
        Person alay2 = new Person(alay);
        System.out.println(alay2.toString());
        
        Person shashank = new Person();
        shashank.setName();
        System.out.println("Name: " + shashank.getName());
        shashank.setAddress();
        System.out.println("Address: " + shashank.getAddress());
        shashank.setPhone();
        System.out.println("Phone: " + shashank.getPhone());
        shashank.setAge();
        System.out.println("Age: " + shashank.getAge());
        shashank.setGender();
        System.out.println("Gender: " + shashank.getGender());
        
        System.out.println("-----------------------------\n" + shashank.toString());
        
        Person saloni = new Person();
        saloni.setData();
        System.out.println(saloni.toString());

        
        Employee emp1 = new Employee("Mandeep", "ind", "222222", 25, 'F', "F101", 20, "01 June 2013");
        System.out.println(emp1.toString());
        
        Employee emp2 = new Employee("Shivam", "Gujarat", "4234234", 23, 'M', "P123", 30, "13 May 2017");
        System.out.println(emp2.toString());
        */
        
        BankAccount bank = new BankAccount(1, "BMO", "8797987797979", 2000);
        System.out.println(bank.toString());
        
    }  
    
}
